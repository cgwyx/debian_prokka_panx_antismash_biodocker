#Roadmap
  x rename visualization output
    x dataset/YourSpecies/
                          geneCluster.json
                          genePresence.json
                          strainMetainfo.json
                          coreGenomeTree.json
                          geneCluster/
                              GC_0000001.json
                              ...
  
  x column for gene names
  - clean-up step removing tmp files
  - catch logs and put them into a log folder
  - mapping
  
  - blastn all-against-all for rRNAs and other non-translated features such as tRNAs
  - adjust tree vis for >200 nodes
